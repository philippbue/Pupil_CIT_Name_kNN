function [valid1_subset, valid3_subset] = random_val_subset(val_subset)

list1 = val_subset.trialnumber(val_subset.T1 == 1);
list3 = val_subset.trialnumber(val_subset.T1 == 3);

valid_trials1 = list1(randperm(length(list1)));
valid_trials3 = list3(randperm(length(list1)));

% Reshape to be used in loop
valid_trials1 = reshape(valid_trials1,1,[]);
valid_trials3 = reshape(valid_trials3,1,[]);

x = 1;
for i = valid_trials1
valid1_subset(x, :) = val_subset(val_subset.trialnumber == i, :);
    x = x + 1;
end
x = 1;
for i = valid_trials3
valid3_subset(x, :) = val_subset(val_subset.trialnumber == i, :);
    x = x + 1;
end


% Merge Subsets
random_val_subset = vertcat(valid1_subset,valid3_subset);


assignin('base','random_val_subset', random_val_subset);

end


