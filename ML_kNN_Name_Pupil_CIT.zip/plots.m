%% Plots
% Dock all figures
set(0,'DefaultFigureWindowStyle','docked')

main = readtable ("pupil_name_main.xlsx");
main(:, 66:145) = [];
main(main.T1 == 2, :) = [];
main.correct_T1 = [];
main.correct_T2 = [];
main.T1pos = [];
main.blockno = [];
main.subject_parity = [];

% Note: T1 = Probe, T2 = Target, T3 = Control
accuracies = [0.3256	0.4856	0.559	0.5224	0.5446	0.533	0.5564	0.4626	0.6226...
    0.5928	0.3606	0.4096	0.658	0.3834	0.647	0.499	0.6292	0.5634	0.392...
    0.3946	0.875	0.4936	0.5928	0.504	0.4544	0.4538	0.4478	0.7364	0.5464...
    0.7932	0.4884];

% Above Chance

count = 0;
for i = [3,4,5,6,7,9, 10,13,15,17,18,21,23,24,28,29,30]
     count = count + 1;
    figure1 = subplot(9,2,count);
    
    
    % subset stores all variables for subject i
    subset = main(main.subject_nr == i, :);
    % Subsets for each target (T1, T2, T2)
    subset_t1 = subset(subset.T1 == 1, :); 
    %subset_t2 = subset(subset.T1 == 2, :);
    subset_t3 = subset(subset.T1 == 3, :);
    
    %% Statistics for T1, T2, T3
    for a = 0:59
      %% stats_t1: T1 Statistics 
      % Row 1: Count of Trials
      stats_t1(1, a +1) = a;
      
      % Row 2: Mean
      stats_t1(2, a+1) = mean(subset_t1.("locked_pupil" + a),'omitnan');
      m = mean(subset_t1.("locked_pupil" + a),'omitnan');
      
      % Row 3: SD
      stats_t1(3, a+1) = std(subset_t1.("locked_pupil" + a),'omitnan');
      sd = std(subset_t1.("locked_pupil" + a),'omitnan');
      
      % Row 4: SE
      stats_t1(4, a+1) = sd/sqrt(60);
      se = sd/sqrt(60);
      
      % Row 5: T-Score
      stats_t1(5, a+1)= tinv([0.975], 60 - 1);
      ts = tinv([0.975], 60 - 1);
      
      % CI
      % Row 6: CI Lower
      stats_t1(6, a+1)= m - ts * se;
      % Row 7: CI Upper
      stats_t1(7, a+1)=m + ts * se;
      
    
    %% T2 Statistics
      % Row 1: Count of Trials
     % stats_t2(1, a +1) = a;
      
      % Row 2: Mean
     % stats_t2(2, a+1) = mean(subset_t2.("locked_pupil" + a),'omitnan');
     % m = mean(subset_t2.("locked_pupil" + a),'omitnan');
      
      % Row 3: SD
     % stats_t2(3, a+1) = std(subset_t2.("locked_pupil" + a),'omitnan');
     % sd = std(subset_t2.("locked_pupil" + a),'omitnan');
      
      % Row 4: SE
     % stats_t2(4, a+1) = sd/sqrt(60);
      %se = sd/sqrt(60);
      
      % Row 5: T-Score
     % stats_t2(5, a+1)= tinv([0.975], 60 - 1);
    %  ts = tinv([0.975], 60 - 1);
      
      % CI
      % Row 6: CI Lower
    %  stats_t2(6, a+1)= m - ts * se;
      
      % Row 7: CI Upper
     % stats_t2(7, a+1)= m + ts * se;
    
    %% T3 Statistics
      % Row 1: Count of Trials
      stats_t3(1, a +1) = a;
      
      % Row 2: Mean
      stats_t3(2, a+1) = mean((subset_t3.("locked_pupil" + a)),'omitnan');
      m = mean(subset_t3.("locked_pupil" + a),'omitnan');
      
      % Row 3: SD
      stats_t3(3, a+1) = std(subset_t3.("locked_pupil" + a),'omitnan');
      sd = std(subset_t3.("locked_pupil" + a),'omitnan');
      
      % Row 4: SE
      stats_t3(4, a+1) = sd/sqrt(60);
      se = sd/sqrt(60);
      
      % Row 5: T-Score
      stats_t3(5, a+1)= tinv([0.975], 60 - 1);
      ts = tinv([0.975], 60 - 1);
      
      % CI
      % Row 6: CI Lower
      stats_t3(6, a+1)= m - ts * se;
      
      % Row 7: CI Upper
      stats_t3(7, a+1)= m + ts * se;
    end

    %% Plot 95% CI the results and save the Plot per participant
   % figure(i);
   % hold on;
    %plot(stats_t1(1, :), stats_t1(2, :), 'Color', 'red')
    %ciplot(stats_t1(7, :),stats_t1(6, :),0:59,'red');
   % hold on; 
    
    %plot(stats_t2(1, :), stats_t2(2, :), 'Color', 'blue')
    %ciplot(stats_t2(7, :),stats_t2(6, :),0:59,'blue');
   % hold on;
    
    %plot(stats_t3(1, :), stats_t3(2, :), 'Color', 'green')
   % ciplot(stats_t3(7, :),stats_t3(6, :),0:59,'green');
    
   % %% Plot SE 
    %% T1 SE Upper & Lower Bound
    % SE Lower Bounds
   stats_t1(8, :) = stats_t1(2, :) -  stats_t1(4, :);
    % SE Upper Bound 
    stats_t1(9, :) = stats_t1(2, :) +  stats_t1(4, :);
    
    %% T2 SE Upper & Lower Bound
    % SE Lower Bounds
    %stats_t2(8, :) = stats_t2(2, :) -  stats_t2(4, :);
    % SE Upper Bound 
    %stats_t2(9, :) = stats_t2(2, :) +  stats_t2(4, :);
    
    %% T3 SE Upper & Lower Bound
    % SE Lower Bounds
    stats_t3(8, :) = stats_t3(2, :) -  stats_t3(4, :);
    % SE Upper Bound 
    stats_t3(9, :) = stats_t3(2, :) +  stats_t3(4, :);
    
    
    % Plot
    %figure(i);
    hold on;
    
    plot1 = plot(stats_t1(1, :), stats_t1(2, :), 'Color', 'red');
    ciplot(stats_t1(8, :),stats_t1(9, :),0:59,'red');
    hold on; 
    
 %  plot(stats_t2(1, :), stats_t2(2, :), 'Color', 'blue')
   %ciplot(stats_t2(8, :),stats_t2(9, :),0:59,'blue');
  % hold on;
    
   plot2 = plot(stats_t3(1, :), stats_t3(2, :), 'Color', 'green');
   ciplot(stats_t3(8, :),stats_t3(9, :),0:59,'green');
   
   title("Participant: " + i + " (Accuracy: " + accuracies(i) + "%)");
  
end

 legend([plot1 plot2],'Real Name (Critical Probe)', 'Control Name (Irrelevant Distractor)')
 
 
 % Below chance
 
count = 0;
for i = [1,2,8,11,12,14,16,19,20,22,25,26,27,31]
     count = count + 1;
    figure1 = subplot(7,2,count);
    
    
    % subset stores all variables for subject i
    subset = main(main.subject_nr == i, :);
    % Subsets for each target (T1, T2, T2)
    subset_t1 = subset(subset.T1 == 1, :); 
    %subset_t2 = subset(subset.T1 == 2, :);
    subset_t3 = subset(subset.T1 == 3, :);
    
    %% Statistics for T1, T2, T3
    for a = 0:59
      %% stats_t1: T1 Statistics 
      % Row 1: Count of Trials
      stats_t1(1, a +1) = a;
      
      % Row 2: Mean
      stats_t1(2, a+1) = mean(subset_t1.("locked_pupil" + a),'omitnan');
      m = mean(subset_t1.("locked_pupil" + a),'omitnan');
      
      % Row 3: SD
      stats_t1(3, a+1) = std(subset_t1.("locked_pupil" + a),'omitnan');
      sd = std(subset_t1.("locked_pupil" + a),'omitnan');
      
      % Row 4: SE
      stats_t1(4, a+1) = sd/sqrt(60);
      se = sd/sqrt(60);
      
      % Row 5: T-Score
      stats_t1(5, a+1)= tinv([0.975], 60 - 1);
      ts = tinv([0.975], 60 - 1);
      
      % CI
      % Row 6: CI Lower
      stats_t1(6, a+1)= m - ts * se;
      % Row 7: CI Upper
      stats_t1(7, a+1)=m + ts * se;
      
    
    %% T2 Statistics
      % Row 1: Count of Trials
     % stats_t2(1, a +1) = a;
      
      % Row 2: Mean
     % stats_t2(2, a+1) = mean(subset_t2.("locked_pupil" + a),'omitnan');
     % m = mean(subset_t2.("locked_pupil" + a),'omitnan');
      
      % Row 3: SD
     % stats_t2(3, a+1) = std(subset_t2.("locked_pupil" + a),'omitnan');
     % sd = std(subset_t2.("locked_pupil" + a),'omitnan');
      
      % Row 4: SE
     % stats_t2(4, a+1) = sd/sqrt(60);
      %se = sd/sqrt(60);
      
      % Row 5: T-Score
     % stats_t2(5, a+1)= tinv([0.975], 60 - 1);
    %  ts = tinv([0.975], 60 - 1);
      
      % CI
      % Row 6: CI Lower
    %  stats_t2(6, a+1)= m - ts * se;
      
      % Row 7: CI Upper
     % stats_t2(7, a+1)= m + ts * se;
    
    %% T3 Statistics
      % Row 1: Count of Trials
      stats_t3(1, a +1) = a;
      
      % Row 2: Mean
      stats_t3(2, a+1) = mean((subset_t3.("locked_pupil" + a)),'omitnan');
      m = mean(subset_t3.("locked_pupil" + a),'omitnan');
      
      % Row 3: SD
      stats_t3(3, a+1) = std(subset_t3.("locked_pupil" + a),'omitnan');
      sd = std(subset_t3.("locked_pupil" + a),'omitnan');
      
      % Row 4: SE
      stats_t3(4, a+1) = sd/sqrt(60);
      se = sd/sqrt(60);
      
      % Row 5: T-Score
      stats_t3(5, a+1)= tinv([0.975], 60 - 1);
      ts = tinv([0.975], 60 - 1);
      
      % CI
      % Row 6: CI Lower
      stats_t3(6, a+1)= m - ts * se;
      
      % Row 7: CI Upper
      stats_t3(7, a+1)= m + ts * se;
    end

    %% Plot 95% CI the results and save the Plot per participant
   % figure(i);
   % hold on;
    %plot(stats_t1(1, :), stats_t1(2, :), 'Color', 'red')
    %ciplot(stats_t1(7, :),stats_t1(6, :),0:59,'red');
   % hold on; 
    
    %plot(stats_t2(1, :), stats_t2(2, :), 'Color', 'blue')
    %ciplot(stats_t2(7, :),stats_t2(6, :),0:59,'blue');
   % hold on;
    
    %plot(stats_t3(1, :), stats_t3(2, :), 'Color', 'green')
   % ciplot(stats_t3(7, :),stats_t3(6, :),0:59,'green');
    
   % %% Plot SE 
    %% T1 SE Upper & Lower Bound
    % SE Lower Bounds
   stats_t1(8, :) = stats_t1(2, :) -  stats_t1(4, :);
    % SE Upper Bound 
    stats_t1(9, :) = stats_t1(2, :) +  stats_t1(4, :);
    
    %% T2 SE Upper & Lower Bound
    % SE Lower Bounds
    %stats_t2(8, :) = stats_t2(2, :) -  stats_t2(4, :);
    % SE Upper Bound 
    %stats_t2(9, :) = stats_t2(2, :) +  stats_t2(4, :);
    
    %% T3 SE Upper & Lower Bound
    % SE Lower Bounds
    stats_t3(8, :) = stats_t3(2, :) -  stats_t3(4, :);
    % SE Upper Bound 
    stats_t3(9, :) = stats_t3(2, :) +  stats_t3(4, :);
    
    
    % Plot
    %figure(i);
    hold on;
    
    plot1 = plot(stats_t1(1, :), stats_t1(2, :), 'Color', 'red');
    ciplot(stats_t1(8, :),stats_t1(9, :),0:59,'red');
    hold on; 
    
 %  plot(stats_t2(1, :), stats_t2(2, :), 'Color', 'blue')
   %ciplot(stats_t2(8, :),stats_t2(9, :),0:59,'blue');
  % hold on;
    
   plot2 = plot(stats_t3(1, :), stats_t3(2, :), 'Color', 'green');
   ciplot(stats_t3(8, :),stats_t3(9, :),0:59,'green');
   
   title("Participant: " + i + " (Accuracy: " + accuracies(i) + "%)");
  
end

 legend([plot1 plot2],'Real Name (Critical Probe)', 'Control Name (Irrelevant Distractor)')