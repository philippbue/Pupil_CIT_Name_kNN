% Install Statistics & ML ToolBox

% Import the Data
main = readtable ("pupil_name_main.xlsx");
main(:, 66:145) = [];
% main(main.T1 == 2, :) = [];
main.correct_T1 = [];
main.correct_T2 = [];
main.T1pos = [];
main.blockno = [];
main.subject_parity = [];

% Only Probe and Control
index = main.T1 ~=2; 
main2 = main(index, :);
main2.locked_pupil49 = [];
main2.locked_pupil50 = [];
main2.locked_pupil51 = [];
main2.locked_pupil52 = [];
main2.locked_pupil53 = [];
main2.locked_pupil54 = [];
main2.locked_pupil55 = [];
main2.locked_pupil56 = [];
main2.locked_pupil57 = [];
main2.locked_pupil58 = [];
main2.locked_pupil59 = [];

time = [1:60];
index_1 = main2.T1 == 1;
index_3 = main2.T1 == 3;
a = 0;
for i = 1:47
stats_all(1 ,i) = mean((main2.("locked_pupil" + a)(index_1)), 'omitnan');
stats_all(2 ,i) = mean((main2.("locked_pupil" + a)(index_3)), 'omitnan');
a = a + 1;
end 

stats_all(1, 48) = 1
stats_all(2, 48) = 2


plot2 = plot(time, stats_all, 'Color', 'green');
   legend([plot1, plot2],'Real Name (Critical Probe)', 'Control Name (Irrelevant Distractor)')


subsets = table();



