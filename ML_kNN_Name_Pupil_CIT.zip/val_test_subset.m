function [test1_subset, test3_subset, valid1_subset, valid3_subset] = val_test_subset(test_split, subset)

list1 = subset.trialnumber(subset.T1 == 1);
list3 = subset.trialnumber(subset.T1 == 3);

valid_trials1 = list1(randperm(length(list1)));
valid_trials3 = list3(randperm(length(list1)));

test_trials1 = valid_trials1(test_split, 1);
test_trials3 = valid_trials3(test_split, 1);

valid_trials1(41:60) = [];
valid_trials3(41:60) = [];


% Reshape to be used in loop
valid_trials1 = reshape(valid_trials1,1,[]);
valid_trials3 = reshape(valid_trials3,1,[]);

test_trials1 = reshape(test_trials1, 1, []);
test_trials3 = reshape(test_trials3, 1, []);

x = 1;
for i = valid_trials1
valid1_subset(x, :) = subset(subset.trialnumber == i, :);
    x = x + 1;
end
x = 1;
for i = valid_trials3
valid3_subset(x, :) = subset(subset.trialnumber == i, :);
    x = x + 1;
end
x = 1;
for i = test_trials1
test1_subset(x, :) = subset(subset.trialnumber == i, :);
    x = x + 1;
end
x = 1;
for i = test_trials3
test3_subset(x, :) = subset(subset.trialnumber == i, :);
    x = x + 1;
end

% Merge Subsets
val_subset = vertcat(valid1_subset,valid3_subset);

test_subset = vertcat(test1_subset,test3_subset);

assignin('base','val_subset', val_subset);
assignin('base','test_subset', test_subset);

end

