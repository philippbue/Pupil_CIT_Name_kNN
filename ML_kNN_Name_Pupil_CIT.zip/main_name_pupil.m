%% Preparation
% Install Statistics & ML ToolBox


for i = 1:1
participant_nr = 1;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


end
for i = 1:25
participant_nr = 2;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 3;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 4;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 5;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 6;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 7;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 8;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 9;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end

for i = 1:25
participant_nr = 10;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end

for i = 1:25
participant_nr = 11;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 12;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 13;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 14;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 15;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 16;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 17;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 18;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 19;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 20;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 21;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 22;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 23;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 24;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 25;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 26;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 27;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 28;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 29;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 30;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end
for i = 1:25
participant_nr = 31;
%% Calculate Optimal Timewindow per Participant/ Only upper bound
%optimal_window = pos_min_max_diff(participant_nr, [0], [44:59]);
optimal_window = [0, 50];

%% Import Data (SubjetcNr, Optimal Window)
subset = get_data(participant_nr, optimal_window);

%% Validation and Testing Subsets (Last 40% For testing)
val_test_subset([41:60], subset);



%% 100 Random Permutation of val_subset
for p = 1:100
random_val_subset(val_subset);


%% Means per Timeslice based on 20 Observations
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:30];
for a = 1:2
     if min(slice) < 81
     val_means(a, count) = mean(random_val_subset.("locked_pupil" + (i))(slice));
     slice = slice + 40;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     val_means_time(a, count) = mean(val_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end


%% Max Means
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(val_means(i, :));
end
for i = [2]
val_means_time(i, position) = max(val_means(i, :));
end
%% Steepest positive Slope
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end
for i = [2]
val_means_time(i, position) = max(gradient(val_means(i, :)));
end

%% Class 
position = width(val_means_time) + 1;
for i = [1]
val_means_time(i, position) = 1;
end
for i = [2]
val_means_time(i, position) = 3;
end


val_final = array2table(val_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
val_final_final = val_final; 
else
val_final_final = vertcat(val_final_final, val_final);

end
clear val_means_time
clear random_val_subset
end

%clear slice
%clear position
%clear p
%clear i
%clear count
%clear a


%% Test Subset 
for p = 1:100

random_test_subset(test_subset);

% Means over time 
count = 1;
for i = min(optimal_window): max(optimal_window)-1
slice = [1:15];
for a = 1:2
     if min(slice) < 81
     test_means(a, count) = mean(random_test_subset.("locked_pupil" + (i))(slice));
     slice = slice + 20;
     else
     end
end
count = count + 1;
end


%% Means over time window
count = 1;
slice = [1:5];
% Width/ Number columns means divided by slice
for i = 1:10
for a = 1:2
     if min(slice) < 51
     test_means_time(a, count) = mean(test_means(a ,slice));
     else
     end
end
slice = slice + 5;
count = count + 1;
end

% Max_ Mean 
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(test_means(i, :));
end
for i = [2]
test_means_time(i, position) = max(test_means(i, :));
end
% Max_Slope
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
for i = [2]
test_means_time(i, position) = max(gradient(test_means(i, :)));
end
% Class
position = width(test_means_time) + 1;
for i = [1]
test_means_time(i, position) = 1;
end
for i = [2]
test_means_time(i, position) = 3;
end


test_final = array2table(test_means_time,...
        'VariableNames',{'T0_4', 'T5_9','T10_14', 'T15_19', 'T20_24', 'T25_29',...
        'T30_34','T_35_39', 'T40_44', 'T45_50', 'Max_Mean', 'Max Slope', 'Class'});

if p == 1
test_final_final = test_final; 
else
test_final_final = vertcat(test_final_final, test_final);
end 
clear test_means_time
clear random_test_subset
end

test = test_final_final.Class;


trainedModel = fitcknn(val_final_final, 'Class', 'NumNeighbors',1, 'Standardize', 1);


yfit = predict(trainedModel, test_final_final);

% Model to predict
accuracy = (sum(yfit == test))/200;


disp(participant_nr)
disp(accuracy)


clear all
end