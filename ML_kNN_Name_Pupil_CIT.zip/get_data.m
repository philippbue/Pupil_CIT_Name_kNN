function [subset] = get_data(subject_nr,optimal_window)

%% Load Data & Clean
main = readtable ("pupil_name_main.xlsx");
main(:, 66:145) = [];
main(main.T1 == 2, :) = [];
main.correct_T1 = [];
main.correct_T2 = [];
main.T1pos = [];
main.blockno = [];
main.subject_parity = [];

%% Create Subset per participant 
for i = subject_nr
% Note: T1 = Probe, T2 = Target, T3 = Control

% Subset Data for every participant
subset = main(main.subject_nr == i, :);
subset.subject_nr = [];

for a = max(optimal_window):59
 subset.("locked_pupil" + a) = [];
end
end
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
end

