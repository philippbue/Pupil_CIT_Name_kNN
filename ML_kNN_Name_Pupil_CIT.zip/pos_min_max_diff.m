function [time_window] = pos_min_max_diff(subject_nr, first_trials, last_trials)
% Import & Clean the Data
main = readtable ("pupil_name_main.xlsx");
main(:, 66:145) = [];
main(main.T1 == 2, :) = [];
main.correct_T1 = [];
main.correct_T2 = [];
main.T1pos = [];
main.blockno = [];
main.subject_parity = [];
main.trialnumber = [];


% Create Subsets per Participant

for i = subject_nr
main_subset = main((main.subject_nr == i), :);    

for a = first_trials
%% Find Optimal Time window
% T1: Earliest largest difference
means(1, a + 1) = abs((mean((main_subset.("locked_pupil" + a)(main_subset.T1 == 1)),'omitnan')));
means(2, a + 1) = abs((mean((main_subset.("locked_pupil" + a)(main_subset.T1 == 3)),'omitnan')));
end
diff = abs((means(1, :) - means(2, :)));
max_diff = max(diff);
max_diff_pos = find(diff == max_diff);

% Fill spots in between
means(1, (max(first_trials) + 1 : min(last_trials) - 1)) = 0;
means(1, (max(first_trials) + 1 : min(last_trials) - 1)) = 10000;

% T2: Latest Smallest difference
for a = last_trials
%% Find Optimal Time window
% T1: Earliest largest difference
means(1, a + 1) = abs((mean((main_subset.("locked_pupil" + a)(main_subset.T1 == 1)),'omitnan')));
means(2, a + 1) = abs((mean((main_subset.("locked_pupil" + a)(main_subset.T1 == 3)),'omitnan')));
end   
diff = abs((means(1, last_trials + 1) - means(2, last_trials + 1)));
min_diff = min(diff);
min_diff_pos = find(diff == min_diff) + min(last_trials);
end
time_window = [max_diff_pos - 1, min_diff_pos - 1];

end

